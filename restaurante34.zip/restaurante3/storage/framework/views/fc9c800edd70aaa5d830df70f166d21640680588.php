<?php
    $languages = (isset($logged_user_data['languages']))?$logged_user_data['languages']:[];
    $selected_language = (isset($logged_user_data['selected_language']))?$logged_user_data['selected_language']:'en - English';
?>
<footer class="container-fluid p-3 <?php echo e((isset($fixed_footer) && $fixed_footer) ? "fixed-bottom" : ""); ?>">
    <div class="d-flex justify-content-between">
        <span>&nbsp;© <?php echo e(date("Y")); ?>-<?php echo e(date("Y", strtotime("+1 year"))); ?> <?php echo e(config('app.company')); ?> &middot; <span class="text-muted">v5.2</span></span>
        <languageswitchercomponent :languages="<?php echo e(json_encode($languages)); ?>" :selected_language="<?php echo e(json_encode($selected_language)); ?>"></languageswitchercomponent>
    </div>
</footer><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/footer.blade.php ENDPATH**/ ?>