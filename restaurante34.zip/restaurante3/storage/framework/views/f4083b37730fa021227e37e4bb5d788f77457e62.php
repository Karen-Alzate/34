<?php $__env->startSection("content"); ?>
<addpaymentmethodcomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :payment_method_data="<?php echo e(json_encode($payment_method_data)); ?>"></addpaymentmethodcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/payment_method/add_payment_method.blade.php ENDPATH**/ ?>