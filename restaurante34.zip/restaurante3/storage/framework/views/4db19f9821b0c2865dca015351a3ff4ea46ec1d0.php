<?php $__env->startSection("content"); ?>
<addsuppliercomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :supplier_data="<?php echo e(json_encode($supplier_data)); ?>"></addsuppliercomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/supplier/add_supplier.blade.php ENDPATH**/ ?>