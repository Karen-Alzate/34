<?php $__env->startSection("content"); ?>
<addinvoicecomponent :currency_list="<?php echo e(json_encode($currency_list)); ?>" :invoice_data="<?php echo e(json_encode($invoice_data)); ?>" :tax_options="<?php echo e(json_encode($tax_options)); ?>"></addinvoicecomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/invoice/add_invoice.blade.php ENDPATH**/ ?>