<div class="side-nav pl-sm-0 pl-lg-4 pl-xl-4">
    <ul class="list-unstyled modules">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_key_id => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php $sub_menu_exists = (isset($menu['sub_menu']))?"dropdown-toggle":""; ?>
            <?php $data_toggle_check = (isset($menu['sub_menu']))?'collapse':""; ?>
            <?php $main_route = (isset($menu['route']) && $menu['route']!='')?route($menu['route']):'#'; ?>
            <?php $menu_selected = ($menu['menu_key'] == $menu_key)?"menu-selected selected-menu-bg":""; ?>
            <?php $menu_icon = (isset($menu['icon']))?'<i class="'.$menu['icon'].' main-menu-icon"></i>':''; ?>
            
            <li class="">
                
                <a href="<?php echo e(($sub_menu_exists == '')? $main_route : '#menu'.$menu_key_id); ?>"  data-toggle="<?php echo e($data_toggle_check); ?>" aria-expanded="false" class="<?php echo e($sub_menu_exists); ?> <?php echo e($menu_selected); ?> module-parent">
                    <span class="main-menu-text text-truncate"><?php echo $menu_icon; ?> <?php echo e(__($menu['label'])); ?></span>
                </a>
                
                <?php if(isset($menu['sub_menu'])): ?>
                <?php $submenu_toggle = (isset($menu['sub_menu']) && ($menu['menu_key'] == $menu_key))?'show in':""; ?>
                <ul class="collapse list-unstyled module <?php echo e($submenu_toggle); ?>" id="menu<?php echo e($menu_key_id); ?>" aria-expanded="false">
                    
                    <?php $__currentLoopData = $menu['sub_menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $submenu_selected_bg = (isset($sub_menu["menu_key"]) && isset($sub_menu_key))?(($sub_menu["menu_key"] == $sub_menu_key)?"selected-menu-bg":""):""; ?>
                    <?php $submenu_selected = (isset($sub_menu["menu_key"]) && isset($sub_menu_key))?(($sub_menu["menu_key"] == $sub_menu_key)?"submenu-selected":""):""; ?>
                    <?php $route = (isset($sub_menu['route']) && $sub_menu['route']!='')?route($sub_menu['route']):'#'; ?>
                    
                    <li class="<?php echo e($submenu_selected_bg); ?>">
                        <a href="<?php echo e($route); ?>" class="<?php echo e($submenu_selected); ?> sub-menu-text text-truncate"><?php echo e(__($sub_menu['label'])); ?></a>
                    </li>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </ul>
                <?php endif; ?>
            
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/side_nav.blade.php ENDPATH**/ ?>