<?php $__env->startSection("content"); ?>
<addtargetcomponent :target_data="<?php echo e(json_encode($target_data)); ?>" :store="<?php echo e(json_encode($store)); ?>"></addtargetcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/target/add_target.blade.php ENDPATH**/ ?>