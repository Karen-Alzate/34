<?php $__env->startSection("content"); ?>
<addmeasurementunitcomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :measurement_unit_data="<?php echo e(json_encode($measurement_unit_data)); ?>"></addmeasurementunitcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/measurement_unit/add_measurement_unit.blade.php ENDPATH**/ ?>