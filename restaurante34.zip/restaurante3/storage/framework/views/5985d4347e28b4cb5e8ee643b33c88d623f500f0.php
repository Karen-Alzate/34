<?php $__env->startSection("content"); ?>
<addbusinessregistercomponent :billing_counters="<?php echo e(json_encode($billing_counters)); ?>"></addbusinessregistercomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/business_register/add_business_register.blade.php ENDPATH**/ ?>