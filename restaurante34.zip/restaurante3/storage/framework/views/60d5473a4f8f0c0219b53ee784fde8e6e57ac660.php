<?php $__env->startSection("content"); ?>
<updatedatacomponent :upload_options = "<?php echo e(json_encode($upload_options)); ?>" :templates="<?php echo e(json_encode($templates)); ?>"></updatedatacomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/import/update_data.blade.php ENDPATH**/ ?>