<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/digital_menu_orders.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<digitalmenuorderscomponent :edit_order_link="<?php echo e(json_encode($edit_order_link)); ?>"  :edit_order_access="<?php echo e(json_encode($edit_order_access)); ?>"></digitalmenuorderscomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/order/digital_menu/digital_menu_orders.blade.php ENDPATH**/ ?>