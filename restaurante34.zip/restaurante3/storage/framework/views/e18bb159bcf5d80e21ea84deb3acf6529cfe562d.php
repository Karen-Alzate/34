<?php $__env->startSection("content"); ?>
<div class="row">
    <div class="col-md-12">
        
        <div class="d-flex flex-wrap mb-4">
            <div class="mr-auto">
                <span class="text-title"><?php echo e(__("Purchase Orders")); ?></span>
            </div>
            <div class="">
                <?php if(check_access(array('A_ADD_PURCHASE_ORDER'), true)): ?>
                    <a href="<?php echo e(route('add_purchase_order')); ?>" role="button" class="btn btn-primary"><?php echo e(__("New Purchase Order")); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-responsive">
            <table id="listing-table" class="table display nowrap w-100">
                <thead>
                    <tr>
                        <th><?php echo e(__("PO Number")); ?></th>
                        <th><?php echo e(__("PO Reference #")); ?></th>
                        <th><?php echo e(__("Supplier Name")); ?></th>
                        <th><?php echo e(__("Order Date")); ?></th>
                        <th><?php echo e(__("Order Due Date")); ?></th>
                        <th><?php echo e(__("Amount")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Created On")); ?></th>
                        <th><?php echo e(__("Updated On")); ?></th>
                        <th><?php echo e(__("Created By")); ?></th>
                        <th><?php echo e(__("Action")); ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/purchase_orders.js')); ?>"></script>
    <script>
        'use strict';
        var purchase_orders = new PurchaseOrders();
        purchase_orders.load_listing_table();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/purchase_order/purchase_orders.blade.php ENDPATH**/ ?>