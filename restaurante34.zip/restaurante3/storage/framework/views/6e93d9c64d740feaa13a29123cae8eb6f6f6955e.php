<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/billing_summary.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<businessregistersummarycomponent :register_data="<?php echo e(json_encode($register_data)); ?>" :pdf_print="<?php echo e(json_encode($pdf_print)); ?>" :new_order_link="<?php echo e(json_encode($new_order_link)); ?>" :new_order_access="<?php echo e(json_encode($new_order_access)); ?>"></businessregistersummarycomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/business_register/business_register_summary.blade.php ENDPATH**/ ?>