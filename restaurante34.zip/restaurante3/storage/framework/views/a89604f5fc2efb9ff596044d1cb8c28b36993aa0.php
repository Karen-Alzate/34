<script src="<?php echo e(asset('plugins/jquery/jquery-3.4.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/side_nav.js')); ?>"></script>
<script src="<?php echo e(mix('js/app.js')); ?>"></script><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>