<?php $__env->startSection("content"); ?>
<addnotificationcomponent :roles="<?php echo e(json_encode($roles)); ?>" :statuses="<?php echo e(json_encode($statuses)); ?>" :notification_data="<?php echo e(json_encode($notification_data)); ?>"></addnotificationcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/notification/add_notification.blade.php ENDPATH**/ ?>