<div class="dropdown">
    <button class="btn btn-sm btn-outline-primary dropdown-toggle actions-dropdown-btn" type="button" id="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-ellipsis-h actions-dropdown"></i>
    </button>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown">
        <?php if(check_access(array('A_DETAIL_RESTAURANT_TABLE'), true)): ?>
            <a href="<?php echo e($table['detail_link']); ?>" class="dropdown-item"><?php echo e(__("View")); ?></a>
        <?php endif; ?>
        <?php if(check_access(array('A_EDIT_RESTAURANT_TABLE'), true)): ?>
            <a href="edit_table/<?php echo e($table['slack']); ?>" class="dropdown-item"><?php echo e(__("Edit")); ?></a>
        <?php endif; ?>
    </div>
</div><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/table/layouts/table_actions.blade.php ENDPATH**/ ?>