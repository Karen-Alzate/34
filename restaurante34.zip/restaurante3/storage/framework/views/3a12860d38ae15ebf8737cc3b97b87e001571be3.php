<div class="dropdown">
    <button class="btn btn-sm btn-outline-primary dropdown-toggle actions-dropdown-btn" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-ellipsis-h actions-dropdown"></i>
    </button>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
        <?php if(check_access(array('A_DETAIL_CUSTOMER'), true)): ?>
            <a href="<?php echo e($customer['detail_link']); ?>" class="dropdown-item"><?php echo e(__("View")); ?></a>
        <?php endif; ?>
        <?php if(check_access(array('A_EDIT_CUSTOMER'), true)): ?>
            <a href="edit_customer/<?php echo e($customer['slack']); ?>" class="dropdown-item"><?php echo e(__("Edit")); ?></a>
        <?php endif; ?>
    </div>
</div><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/customer/layouts/customer_actions.blade.php ENDPATH**/ ?>