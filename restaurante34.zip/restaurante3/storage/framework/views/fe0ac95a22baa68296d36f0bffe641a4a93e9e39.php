<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/multiselect.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<addproductcomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :taxcodes="<?php echo e(json_encode($taxcodes)); ?>"  :suppliers="<?php echo e(json_encode($suppliers)); ?>" :categories="<?php echo e(json_encode($categories)); ?>" :discount_codes="<?php echo e(json_encode($discount_codes)); ?>" :product_data="<?php echo e(json_encode($product_data)); ?>" :stock_transfer_data="<?php echo e(json_encode($stock_transfer_data)); ?>" :stock_transfer_product_data="<?php echo e(json_encode($stock_transfer_product_data)); ?>" :measurement_units="<?php echo e(json_encode($measurement_units)); ?>" :addon_groups="<?php echo e(json_encode($addon_groups)); ?>"></addproductcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/product/add_product.blade.php ENDPATH**/ ?>