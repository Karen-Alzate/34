<?php $__env->startSection("content"); ?>
<restaurantmenuqrcomponent :menu_link="<?php echo e(json_encode($menu_link)); ?>"></restaurantmenuqrcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/kitchen/restaurant_menu/restaurant_menu_qr.blade.php ENDPATH**/ ?>