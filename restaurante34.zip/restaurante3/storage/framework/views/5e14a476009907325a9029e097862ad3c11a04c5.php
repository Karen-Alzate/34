<div class="dropdown">
    <button class="btn btn-sm btn-outline-primary dropdown-toggle actions-dropdown-btn" type="button" id="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-ellipsis-h actions-dropdown"></i>
    </button>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown">
        <?php if(check_access(array('A_DETAIL_SMS_SETTING'), true)): ?>
        <a href="<?php echo e($sms_setting['detail_link']); ?>" class="dropdown-item"><?php echo e(__("View")); ?></a>
        <?php endif; ?>
        <?php if(check_access(array('A_EDIT_SMS_SETTING'), true)): ?>
            <a href="edit_sms_setting/<?php echo e($sms_setting['slack']); ?>" class="dropdown-item"><?php echo e(__("Edit")); ?></a>
        <?php endif; ?>
    </div>
</div><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/setting/sms/layouts/sms_setting_actions.blade.php ENDPATH**/ ?>