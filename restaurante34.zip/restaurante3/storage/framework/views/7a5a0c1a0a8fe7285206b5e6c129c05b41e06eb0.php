<?php $__env->startSection("content"); ?>
<productquantityalertcomponent></productquantityalertcomponent>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/product_quantity_alert.js')); ?>"></script>
    <script>
        'use strict';
        var product_quantity_alert = new Product_quantity_alert();
        product_quantity_alert.load_listing_table();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/report/product_quantity_alert.blade.php ENDPATH**/ ?>