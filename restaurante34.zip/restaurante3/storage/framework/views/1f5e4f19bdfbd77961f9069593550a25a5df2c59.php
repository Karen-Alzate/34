<?php
    $navbar_logo = config("app.navbar_logo");
    $user_slack = session('slack');
?>

<topnavcomponent :user_slack="<?php echo e(json_encode($user_slack)); ?>" :logged_user_data="<?php echo e(json_encode($logged_user_data)); ?>" :navbar_logo="<?php echo e(json_encode($navbar_logo)); ?>" :quick_links="<?php echo e(json_encode($quick_links)); ?>" :order_page="<?php echo e(json_encode(isset($order)?true:false)); ?>"></topnavcomponent><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/top_nav.blade.php ENDPATH**/ ?>