<?php $__env->startSection("content"); ?>
<addbillingcountercomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :billing_counter_data="<?php echo e(json_encode($billing_counter_data)); ?>"></addbillingcountercomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/billing_counter/add_billing_counter.blade.php ENDPATH**/ ?>