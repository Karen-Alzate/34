<?php $__env->startSection("content"); ?>
<div class="row">
    <div class="col-md-12">
        
        <div class="d-flex flex-wrap mb-4">
            <div class="mr-auto">
                <span class="text-title"><?php echo e(__("SMS Setting")); ?></span>
            </div>
            <div class="">
              
            </div>
        </div>

        <div class="table-responsive">
            <table id="listing-table" class="table display nowrap w-100">
                <thead>
                    <tr>
                        <th><?php echo e(__("SMS Gateway")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Created On")); ?></th>
                        <th><?php echo e(__("Updated On")); ?></th>
                        <th><?php echo e(__("Created By")); ?></th>
                        <th><?php echo e(__("Action")); ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/sms_settings.js')); ?>"></script>
    <script>
        'use strict';
        var sms_settings = new SmsSettings();
        sms_settings.load_listing_table();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/setting/sms/sms_settings.blade.php ENDPATH**/ ?>