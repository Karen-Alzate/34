<?php $__env->startSection("content"); ?>
<addtaxcodecomponent :statuses="<?php echo e(json_encode($statuses)); ?>" :tax_code_data="<?php echo e(json_encode($tax_code_data)); ?>"></addtaxcodecomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/tax_code/add_tax_code.blade.php ENDPATH**/ ?>