<?php $__env->startSection("content"); ?>
    <forgotpasswordcomponent :company_logo = <?php echo e(json_encode($company_logo)); ?>></forgotpasswordcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/entry/forgot_password.blade.php ENDPATH**/ ?>