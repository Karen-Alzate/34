<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
<storestockchartcomponent :store="<?php echo e(json_encode($store)); ?>"></storestockchartcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/report/store_stock_chart.blade.php ENDPATH**/ ?>