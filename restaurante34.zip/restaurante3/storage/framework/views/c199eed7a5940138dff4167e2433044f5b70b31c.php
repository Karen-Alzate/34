<!DOCTYPE html>
<html>
    <head>
        <title>Register Report | <?php echo e($store); ?> | <?php echo e($date); ?></title>
    </head>
    <body>

        <div class='mb-1rem'>
            <table>
                <tr>
                    <td><h2>REGISTER REPORT</h2></td>
                </tr>
            </table>

            <table class='w-100 bordered-table'>
                <tr>
                    <th class='w-50 left'>
                        Store
                    </th>
                    <td class='w-50'>
                        <?php echo e($store); ?>

                    </td>
                </tr>
                <tr>
                    <th class='w-50 left'>
                        Billing Counter
                    </th>
                    <td class='w-50'>
                        <?php echo e($data['billing_counter']['billing_counter_code']); ?> - <?php echo e($data['billing_counter']['counter_name']); ?>

                    </td>
                </tr>
                <tr>
                    <th class='w-50 left'>
                        Opened By
                    </th>
                    <td class='w-50'>
                        <?php echo e($data['user']['fullname']); ?>

                    </td>
                </tr>
                <tr>
                    <th class='w-50 left'>
                        Opened On
                    </th>
                    <td class='w-50'>
                        <?php echo e($data['opening_date_label']); ?>

                    </td>
                </tr>
                <tr>
                    <th class='w-50 left'>
                        Closed On
                    </th>
                    <td class='w-50'>
                        <?php echo e(($data['closing_date_label'])?$data['closing_date_label']:'-'); ?>

                    </td>
                </tr>
            </table>
        </div>

        <div class='mb-1rem'>
            <table class='w-100 bordered-table'>
                <tr>
                    <th class=''>
                        
                    </th>
                    <th class=''>
                        Amount (<?php echo e($currency); ?>)
                    </th>
                    <th class=''>
                        Count
                    </th>
                </tr>
                <tr>
                    <td class=''>
                        Opening Amount
                    </td>
                    <td class=''>
                        <?php echo e($data['opening_amount']); ?>

                    </td>
                    <td class=''>
                        -
                    </td>
                </tr>
                <tr>
                    <td class=''>
                        Closing Amount
                    </td>
                    <td class=''>
                        <?php echo e($data['closing_amount']); ?>

                    </td>
                    <td class=''>
                        -
                    </td>
                </tr>
                <tr>
                    <td class=''>
                        Credit Card Slips
                    </td>
                    <td class=''>
                        -
                    </td>
                    <td class=''>
                        <?php echo e($data['credit_card_slips']); ?>

                    </td>
                </tr>
                <tr>
                    <td class=''>
                        Cheques
                    </td>
                    <td class=''>
                        -
                    </td>
                    <td class=''>
                        <?php echo e($data['cheques']); ?>

                    </td>
                </tr>
                <?php $__currentLoopData = $data['payment_method_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=''>
                        <?php echo e($payment_method['payment_method']); ?>

                    </td>
                    <td class=''>
                        <?php echo e($payment_method['value']); ?>

                    </td>
                    <td class=''>
                        <?php echo e($payment_method['order_count']); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=''>
                        Order Grand Total
                    </td>
                    <td class=''>
                        <?php echo e($data['order_data']['order_value']); ?>

                    </td>
                    <td class=''>
                        <?php echo e($data['order_data']['order_count']); ?>

                    </td>
                </tr>
            </table>
        </div>

        <div class='center'>
            <div class='display-block'>Thank You!</div>
        </div>

    </body>
</html><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/business_register/report/business_register_report_print.blade.php ENDPATH**/ ?>