<!doctype html>
<html lang="en">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="app">
        <body class="container-fluid p-0">
            <?php echo $__env->renderWhen((isset($app_indicator['indicator']) && $app_indicator['indicator'] != ''), 'layouts.app_indicator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <?php echo $__env->make('layouts.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="wrapper">
                <?php echo $__env->make('layouts.side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>     
        </body>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</html><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/layout.blade.php ENDPATH**/ ?>