<span class="bg-warning text-dark p-1 pl-3 pr-3 position-absolute demo-indicator">
    <span class="mx-auto">
        <?php if(isset($app_indicator['indicator'])): ?>
            <?php echo $app_indicator['indicator']; ?>

        <?php endif; ?>
    </span>
</span><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/layouts/app_indicator.blade.php ENDPATH**/ ?>