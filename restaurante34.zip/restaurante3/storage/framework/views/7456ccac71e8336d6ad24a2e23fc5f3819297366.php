<?php $__env->startSection("content"); ?>
<div class="row">
    <div class="col-md-12">
        
        <div class="d-flex flex-wrap mb-4">
            <div class="mr-auto">
                <span class="text-title"><?php echo e(__("Products")); ?></span>
            </div>
            <div class="">
                <?php if(check_access(array('A_ADD_PRODUCT'), true)): ?>
                    <a href="<?php echo e(route('add_product')); ?>" role="button" class="btn btn-primary"><?php echo e(__("New Product")); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-row mb-1">
            <div class="form-group col-md-3">
                <label for="product_type_filter"><?php echo e(__("Filter Product")); ?></label>
                <select name="product_type_filter" id="product_type_filter" class="form-control form-control-custom custom-select">
                    <option value="all">All</option>
                    <option value="billing_products" selected>Billing Products</option>
                    <option value="addon_products">Add-on Products</option>
                    <?php if($restaurant_mode): ?>
                    <option value="ingredients">Ingredients</option>
                    <?php endif; ?>
                </select>
            </div>
        </div>

        <div class="table-responsive">
            <table id="listing-table" class="table display nowrap w-100">
                <thead>
                    <tr>
                        <th><?php echo e(__("Product Code")); ?></th>
                        <th><?php echo e(__("Name")); ?></th>
                        <th><?php echo e(__("Supplier")); ?></th>
                        <th><?php echo e(__("Category")); ?></th>
                        <th><?php echo e(__("Tax Code")); ?></th>
                        <th><?php echo e(__("Discount Code")); ?></th>
                        <th><?php echo e(__("Quantity")); ?></th>
                        <th><?php echo e(__("Amount")); ?></th>
                        <th><?php echo e(__("Status")); ?></th>
                        <th><?php echo e(__("Created On")); ?></th>
                        <th><?php echo e(__("Updated On")); ?></th>
                        <th><?php echo e(__("Created By")); ?></th>
                        <th><?php echo e(__("Action")); ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/products.js')); ?>"></script>
    <script>
        'use strict';
        var products = new Products();
        products.load_listing_table();

        $(document).on('change', '#product_type_filter', function(){
            var product_type = $(this).val();
            event = new CustomEvent("product_type_filter", { "detail": product_type });
            document.dispatchEvent(event);
        });

        $(document).ready(function(){
            var product_type = $('#product_type_filter').val();
            console.log(product_type);
            event = new CustomEvent("product_type_filter", { "detail": product_type });
            document.dispatchEvent(event);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/product/products.blade.php ENDPATH**/ ?>