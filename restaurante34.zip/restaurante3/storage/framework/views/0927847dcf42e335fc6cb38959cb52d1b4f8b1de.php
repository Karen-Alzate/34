<?php $__env->startSection("content"); ?>
<appsettingcomponent :app_setting="<?php echo e(json_encode($setting_data)); ?>"></appsettingcomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/setting/app/app_setting.blade.php ENDPATH**/ ?>