<?php $__env->startSection("content"); ?>
    <signincomponent :is_demo="<?php echo e(json_encode($is_demo)); ?>" :preview_mode = <?php echo e(json_encode($preview_mode)); ?> :company_logo = <?php echo e(json_encode($company_logo)); ?>></signincomponent>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/entry/sign_in.blade.php ENDPATH**/ ?>