<link rel="stylesheet" href="<?php echo e(asset('css/font.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/web.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/labels.css')); ?>">

        
<div class="d-flex flex-column error-invalid-page">
    <div class="justify-content-center mx-auto">
        <div class="p-2">
            <span class="text-headline">Something's Missing.</span>
        </div>
        <div class="p-2">
            <span class="text-title">Sorry, the page you are looking for could not be found</span>
        </div>
        <div class="p-2">
            <a href="/">Back to Home</a>
        </div>
    </div>
</div><?php /**PATH /home/u964887345/domains/nacionalcode.online/public_html/restaurante3/resources/views/errors/404.blade.php ENDPATH**/ ?>